<?php
session_start();
?>

<?php
$_SESSION['tabcount']=0;
//echo "session loaded";
?>

