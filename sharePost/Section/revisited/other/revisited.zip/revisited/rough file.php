<div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions"></div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'></div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity"></div>
                        Answers
                        <!--changes -->
                        <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style="display: inline;" class="question-date"></div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class="write-answer-block">
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class="panel-body answer-body">
            </div>
            <!--answer ends here-->
         </div>
         <!--official block ends here-->
         <!--official block-->
         <div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions">How fast do programmers really code?</div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'>Ashok Kunwar</div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity">2</div>
                        Answers<!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style="display: inline;" class="question-date">14 Dec 2018</div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class="write-answer-block">
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class="panel-body answer-body">
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/sushil.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Sushil Thapa <small>Jan 10, 2019</small></h4>
                     <div class="answer">
                        From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>
                        Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>
                        It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in 
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/kiran.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Kiran Khanal <small>Jan 17, 2019</small></h4>
                     <div class="answer">
                        The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>
                        Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>
                        It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
            </div>
         </div>
         <!--official block ends here-->
         <!--official block-->
         <div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions">How fast do programmers really code?</div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'>Ashok Kunwar</div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity">2</div>
                        Answers<!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style="display: inline;" class="question-date">14 Dec 2018</div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class="write-answer-block">
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class="panel-body answer-body">
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/sushil.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Sushil Thapa <small>Jan 10, 2019</small></h4>
                     <div class="answer">
                        From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>
                        Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>
                        It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in 
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/kiran.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Kiran Khanal <small>Jan 17, 2019</small></h4>
                     <div class="answer">
                        The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>
                        Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>
                        It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
            </div>
         </div>
         <!--official block ends here-->
         <!--official block-->
         <div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions">How fast do programmers really code?</div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'>Ashok Kunwar</div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity">2</div>
                        Answers<!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style="display: inline;" class="question-date">14 Dec 2018</div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class="write-answer-block">
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class="panel-body answer-body">
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/sushil.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Sushil Thapa <small>Jan 10, 2019</small></h4>
                     <div class="answer">
                        From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>
                        Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>
                        It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in 
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/kiran.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Kiran Khanal <small>Jan 17, 2019</small></h4>
                     <div class="answer">
                        The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>
                        Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>
                        It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
            </div>
         </div>
         <!--official block ends here-->
         <!--official block-->
         <div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions">This is a dynamic block,isn't it?</div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'>Ashok Kunwar</div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity">2</div>
                        Answers<!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style='display: inline;' class='question-date'>14 Dec 2018</div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class='write-answer-block'>
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class='panel-body answer-body'>
               <div class='media'>
                  <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/sushil.jpg' width='30' height='30' class='media-object img-circle'></a>
                  <div class='media-body'>
                     <h4 class='media-heading'>Sushil Thapa <small>Jan 10, 2019</small></h4>
                     <div class='answer'>
                        From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>
                        Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>
                        It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in 
                     </div>
                     <div class='comment'>
                     </div>
                  </div>
                  <div class='btn-votes'>
                  </div>
               </div>
               <div class='media'>
                  <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/kiran.jpg' width='30' height='30' class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Kiran Khanal <small>Jan 17, 2019</small></h4>
                     <div class="answer">
                        The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>
                        Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>
                        It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
            </div>
         </div>




         <div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions"></div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'></div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity"></div>
                        Answers
                        <!--changes -->
                        <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style="display: inline;" class="question-date"></div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class="write-answer-block">
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class="panel-body answer-body">
            </div>
            <!--answer ends here-->
         </div>
         <!--official block ends here-->
         <!--official block-->
         <div class="panel" >
            <div class="panel-heading" >
               <a href="profile.html" class="asker-img pull-left"><img alt="Bootstrap Image Preview" src="image/ashok.jpg" class="img-circle" width="40" height="40"></a>
               <div class="panel-heading-right">
                  <h2>
                     <div class="question-id"></div>
                     <div style="display: inherit;" class="questions">How fast do programmers really code?</div>
                  </h2>
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <!--question marks here-->
                  <div class="asker-info" >
                     <a href="profile.html" class="testtt">
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <!--askers profile redirects here-->
                        <span class="glyphicon glyphicon-user" ></span>
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <!--name of asker needs  to be querried --> 
                        <div class='asker-name' style='display: inherit;'>Ashok Kunwar</div>
                     </a>
                     <a href='#' class='btn-toggle-answer-body'>
                        <div style="display: inline;" class="answer-quantity">2</div>
                        Answers<!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                     </a>
                     <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> 
                     <span class='pull-right'>
                        <span class='glyphicon glyphicon-time'></span> <!--changes -->
                        <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->
                        <div style="display: inline;" class="question-date">14 Dec 2018</div>
                        <!--changes --><!--changes --><!--changes -->
                     </span>
                  </div>
               </div>
               <div class="write-answer-block">
                  <!--this dynamically add an answer block here when the user is logged in-->
               </div>
            </div>
            <div class="panel-body answer-body">
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/sushil.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Sushil Thapa <small>Jan 10, 2019</small></h4>
                     <div class="answer">
                        From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>
                        Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>
                        It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in 
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
               <div class="media">
                  <a href="profile.html" class="pull-left"><img alt="Bootstrap Media Preview" src="image/kiran.jpg" width="30" height="30" class="media-object img-circle"></a>
                  <div class="media-body">
                     <h4 class="media-heading">Kiran Khanal <small>Jan 17, 2019</small></h4>
                     <div class="answer">
                        The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>
                        Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>
                        It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.
                     </div>
                     <div class="comment">
                     </div>
                  </div>
                  <div class="btn-votes">
                  </div>
               </div>
            </div>
         </div>
         <!--official block ends here-->
















 x="<!--official block--><div class='panel' >   <div class='panel-heading' ><a href='profile.html' class='asker-img pull-left'><img alt='Bootstrap Image Preview' src='image/ashok.jpg' class='img-circle' width='40' height='40'></a> <div class='panel-heading-right'>   <h2><div class='question-id'></div><div style='display: inherit;' class='questions'>ashok is very busy with his gf?</div></h2>         <!--question marks here-->    <!--question marks here--> <!--question marks here-->                   <!--question marks here-->                   <div class='asker-info' >                       <a href='profile.html' class='testtt'>                         <!--askers profile redirects here-->        <!--askers profile redirects here-->                         <!--askers profile redirects here-->                           <!--askers profile redirects here-->   <span class='glyphicon glyphicon-user' ></span>                         <!--name of asker needs  to be querried -->        <!--name of asker needs  to be querried -->                          <!--name of asker needs  to be querried -->                          <!--name of asker needs  to be querried -->                       <div class='asker-name' style='display: inherit;'>Ashok Kunwar</div>                   </a> <a href='javascript:void(0)' class='btn-toggle-answer-body'> <div style='display: inline;'' class='answer-quantity'>2</div> Answers<!--changes -->     <!--changes --><!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->                  </a> <a href='javascript:void(0)' class='btn-toggle-write-answer'><strong><span class='glyphicon glyphicon-pencil'></span> write answer</strong></a> <span class='pull-right'><span class='glyphicon glyphicon-time'></span> <!--changes -->                   <!--changes --><!--changes --><!--changes --><!--changes --><!--changes -->                  <div style='display: inline;' class='question-date'>14 Dec 2018</div><!--changes --><!--changes --><!--changes -->               </span>                                         </div>                  </div>                                    <div class='write-answer-block'>" + y + "                      <!--this dynamically add an answer block here when the user is logged in-->                  </div>               </div>               <div class='panel-body answer-body'>                  <div class='media'>                    <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/sushil.jpg' width='30' height='30' class='media-object img-circle'></a>                   <div class='media-body'>                        <h4 class='media-heading'>Sushil Thapa <small>Jan 10, 2019</small></h4>                         <div class='answer'>                         From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>                          Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>                          It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in                   </div>                  <div class='comment'>                        </div>                     </div>                                 <div class='btn-votes'>                   </div>                  </div>                  <div class='media'>                    <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/kiran.jpg' width='30' height='30' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading'>Kiran Khanal <small>Jan 17, 2019</small></h4>                      <div class='answer'>                         The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>                          Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>                         It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.                      </div>                           <div class='comment'>                     </div>                     </div>                              <div class='btn-votes'>                </div>                  </div>               </div>            </div>   <!--official block ends here-->";
            
            $(".col-md-7").append(x);
            if($('.panel:last .answer').html().length > 100){
                  var les_text=$('.panel:last .answer').html().substring(0,100);
                  var more_text=$('.panel:last .answer').html().substring(100);

                  $('.panel:last .answer').html("<span>" + les_text + "</span><a href='javascript:void(0)' class='btn_read_more'>read more</a>");
                  $('.panel:last .answer').find("span").append("<span class='more_text'>" + more_text + "</span>");
            }
            $('.answer').on('click','.btn_read_more' , function(e){
                  event.preventDefault();
                  $(this).parent().find('.more_text').show();
                  $(this).replaceWith("<a href='javascript:void(0)' class='btn_read_less'>read less</a>");
            });
            $('.answer').on('click','.btn_read_less' , function(e){
                  event.preventDefault();
                  $(this).parent().find('.more_text').hide();
                  $(this).replaceWith("<a href='javascript:void(0)' class='btn_read_more'>read more</a>");
            });




select * from  question_table q,answer_table a where q.member_id=a.member_id and q.member_id=2
























               x="   <div class='panel-heading'><h2>How fast do programmers really code?</h2></div>   <div class='panel-body'>      <div class='media'>                    <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/ashok.jpg' width='50' height='50' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading'>Ashok Kunwar<small>Jan 10, 2019</small></h4>                       <div class='answer'>                         From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>                          Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>                          It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in understanding the problem you're trying to solve.                       </div>                     </div>                                 <div class='btn-votes'>                      <a href='' class='btn btn-sm btn-default'><span class='glyphicon glyphicon-thumbs-up'></span> | 200</a>                       <a href='' class='btn btn-sm btn-link'><span class='glyphicon glyphicon-thumbs-down'></span> Downvote</a>                     </div>                  </div>                  <div class='media'>                    <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/ashok.jpg' width='50' height='50' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading'>Ashok Kunwar<small>Jan 17, 2019</small></h4>                       <div class='answer'>                         The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>                          Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>                         It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.                         So the common perception offered in film is fairly inaccurate.s                        </div>                     </div>                           <div class='btn-votes'>                      <a href='' class='btn btn-sm btn-default'><span class='glyphicon glyphicon-thumbs-up'></span> | 200</a>                       <a href='' class='btn btn-sm btn-link'><span class='glyphicon glyphicon-thumbs-down'></span> Downvote</a>                     </div>                  </div>               </div>            </div>";



      $(".panel.panel-default").append(x);














<div class='panel-heading'><div class='question-id'></div><h2 class='questions'>How fast do programmers really code?</h2></div>   <div class='panel-body'>      <div class='media'>                    <a href='profile.php' class='pull-left open'><img alt='Bootstrap Media Preview' src='image/ashok.jpg' width='50' height='50' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading '>Ashok Kunwar<small class='question-date'>Jan 10, 2019</small></h4>                       <div class='answer'>                         From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>                          Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>                          It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in understanding the problem you're trying to solve.                       </div>                     </div>                                 <div class='btn-votes'>                      <a href='' class='btn btn-sm btn-default'><span class='glyphicon glyphicon-thumbs-up'></span> | 200</a>                       <a href='' class='btn btn-sm btn-link'><span class='glyphicon glyphicon-thumbs-down'></span> Downvote</a>                     </div>                  </div>                  <div class='media'>                    <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/ashok.jpg' width='50' height='50' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading'>Ashok Kunwar<small>Jan 17, 2019</small></h4>                       <div class='answer'>                         The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>                          Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>                         It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.                         So the common perception offered in film is fairly inaccurate.s                        </div>                     </div>                           <div class='btn-votes'>                      <a href='' class='btn btn-sm btn-default'><span class='glyphicon glyphicon-thumbs-up'></span> | 200</a>                       <a href='' class='btn btn-sm btn-link'><span class='glyphicon glyphicon-thumbs-down'></span> Downvote</a>                     </div>                  </div>               </div>            </div>




















<div class='panel-heading'><div class='question-id'></div><h2 class='questions'>How fast do programmers really code?</h2></div>   <div class='panel-body'>      <div class='media'>                    <a href='profile.html' class='pull-left open'><img alt='Bootstrap Media Preview' src='image/ashok.jpg' width='50' height='50' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading '><div class='asker-name'>Ashok Kunwar</div><small class='question-date'>Jan 10, 2019</small></h4>                       <div class='answer'>                         From my perspective it depends on the problem you're solving. If you've already got a mental model of how to solve the problem, sometimes the limit really is your typing speed.<br><br>                          Most of the time, however, those periods of rabid keyboard bashing are followed and preceded by long periods of head scratching, particularly if it's a difficult problem. Nobody ever invented a compression or path-finding algorithm by typing really fast.<br><br>                          It's important to change people's perception that the work of programmers is motion (typing) rather than thinking. Programming by coincidence (The First Rule of Programming: It's Always Your Fault) can involve a lot of typing, but it's really just a painfully inefficient search strategy that almost universally leads to poor solutions: the real work is in understanding the problem you're trying to solve.                       </div>                     </div>                                 <div class='btn-votes'>                      <a href='' class='btn btn-sm btn-default'><span class='glyphicon glyphicon-thumbs-up'></span> | 200</a>                       <a href='' class='btn btn-sm btn-link'><span class='glyphicon glyphicon-thumbs-down'></span> Downvote</a>                     </div>                  </div>                  <div class='media'>                    <a href='profile.html' class='pull-left'><img alt='Bootstrap Media Preview' src='image/ashok.jpg' width='50' height='50' class='media-object img-circle'></a>                    <div class='media-body'>                        <h4 class='media-heading'>Ashok Kunwar<small>Jan 17, 2019</small></h4>                       <div class='answer'>                         The general answer is definitely “no”. I remember seeing a movie once where two people needed to hack “harder” to “keep out some intruder” and they just started slamming on one keyboard with four hands instead of two. I think this is the most extreme example of the common perception.<br><br>                          Real programming is much slower than most people perceive and therefore extraordinarily expensive. Creating, for example, a 1,000,000 line codebase of useful code literally requires close to 1,000 engineers. It is not like writing a large novel, for example.<br><br>                         It also involves a lot of other activities besides typing (and typing code). Designs and test plans must be created and reviewed, testing must be conducted, and operational       activities like tuning and monitoring must be conducted as well; much of this takes the form of typing narrative descriptions of one’s intent, then presenting them to a larger team, or doing things like pouring over logs to find bugs.                         So the common perception offered in film is fairly inaccurate.s                        </div>                     </div>                           <div class='btn-votes'>                      <a href='' class='btn btn-sm btn-default'><span class='glyphicon glyphicon-thumbs-up'></span> | 200</a>                       <a href='' class='btn btn-sm btn-link'><span class='glyphicon glyphicon-thumbs-down'></span> Downvote</a>                     </div>                  </div>               </div>            </div>










$(this).prev().css('display', 'inline');
      $(this).prev().prev().css('display', 'none');